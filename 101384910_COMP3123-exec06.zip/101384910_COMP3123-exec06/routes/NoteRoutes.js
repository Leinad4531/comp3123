const noteModel = require('../models/NotesModel');
const express = require('express')
const noteRoutes = express.Router()
//TODO - Create a new Note
//http://mongoosejs.com/docs/api.html#document_Document-save

noteRoutes.route('/')
.get((req, res) => {
    res.send("WELCOME TO NOTES")
})
.post((req, res) => {
    
})

noteRoutes.post('/notes', async (req, res) => {
    // Validate request
    try {
        const { noteTitle, noteDescription, priority } = req.body;
    
        if (!noteTitle || !noteDescription || !priority) {
            return res.status(400).send({
                message: "Note fields (noteTitle, noteDescription, and priority) cannot be empty"
            });
        }
    
        const notes = new noteModel({
            noteTitle,
            noteDescription,
            priority
        });
    
        await notes.save();
        res.status(201).send("Note added successfully");
    } catch (error) {
        console.error(error);
        res.status(500).send("An error occurred while adding the note.");
    }
    //TODO - Write your code here to save the note
});

//TODO - Retrieve all Notes
//http://mongoosejs.com/docs/api.html#find_find
noteRoutes.get('/notes',async (req, res) => {
    // Validate request
    try {
        const notes = await noteModel.find({})
        res.status(200).send(notes)
    } catch (error) {
        res.status(500).send(error)
    }
    //TODO - Write your code here to returns all note
});

//TODO - Retrieve a single Note with noteId
//http://mongoosejs.com/docs/api.html#findbyid_findById
noteRoutes.get('/notes/:id',async (req, res) => {
    // Validate request
    try {
        const note = await noteModel.findById(req.params.id);

        if (!note) {
            
            return res.status(404).send('Note not found');
        }

        res.status(200).send(note);
    } catch (error) {
        console.error(error);
        
        res.status(500).send("An error occurred while fetching the note.");
    }
    //TODO - Write your code here to return onlt one note using noteid
});

//TODO - Update a Note with noteId
//http://mongoosejs.com/docs/api.html#findbyidandupdate_findByIdAndUpdate
noteRoutes.put('/notes/:id', async (req, res) => {
    // Validate request
    try {
        
        if (!req.body.noteTitle || !req.body.noteDescription || !req.body.priority) {
            return res.status(400).send({
                message: "Note fields (noteTitle, noteDescription, and priority) cannot be empty"
            });
        }
    
        const note = await noteModel.findByIdAndUpdate(req.params.id, req.body);
    
        if (!note) {
            
            return res.status(404).send('Note not found');
        }
    
        
        res.status(200).send("Note updated successfully");
    } catch (error) {
        console.error(error);

        res.status(500).send("An error occurred while updating the note.");
    }
    //TODO - Write your code here to update the note using noteid
});

//TODO - Delete a Note with noteId
//http://mongoosejs.com/docs/api.html#findbyidandremove_findByIdAndRemove
noteRoutes.delete('/notes/:id',async (req, res) => {
    // Validate request
    try {
        const note = await noteModel.findByIdAndDelete(req.params.id);
    
        if (!note) {
            
            return res.status(404).send('Note not found');
        }
    
        res.status(200).send("Note deleted successfully");
    } catch (error) {
        console.error(error);

        res.status(500).send("An error occurred while deleting the note.");
    }
    //TODO - Write your code here to delete the note using noteid
});

module.exports = noteRoutes;
