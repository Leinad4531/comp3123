const express = require('express');
const app = express();
const port = 8081;

// GET request: /hello
app.get('/hello', (req, res) => {
    res.send('Hello Express JS');
});

// GET request: /user (using query parameters)
app.get('/user', (req, res) => {
    const { firstname, lastname } = req.query;
    res.json({ firstname, lastname });
});

// POST request: /user (using path parameters)
app.post('/user/:firstname/:lastname', (req, res) => {
    const { firstname, lastname } = req.params;
    res.json({ firstname, lastname });
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
